jQuery(document).ready(function($) {
	"use strict";

	/* Variables */
	var header = $('.header');
	var hamburger = $('.hamburger_container');
	var menu = $('.hamburger_menu');
	var menuActive = false;
	var hamburgerClose = $('.hamburger_close');
	var fsOverlay = $('.fs_menu_overlay');
	var map;

	// Set header position and behavior on scroll and resize
	setHeader();

	// Event listeners for resize and scroll
	$(window).on('resize scroll', function() {
			setHeader();
	});

	// Initialize components
	initMenu();
	initGoogleMap();

	/* Set header behavior on scroll and resize */
	function setHeader() {
			if (window.innerWidth < 992) {
					header.css({'top': $(window).scrollTop() > 100 ? "0" : "0"});
			} else {
					header.css({'top': $(window).scrollTop() > 100 ? "-50px" : "0"});
			}

			// Close menu when window is resized to larger than 991px
			if (window.innerWidth > 991 && menuActive) {
					closeMenu();
			}
	}

	/* Initialize hamburger menu functionality */
	function initMenu() {
			if (hamburger.length) {
					hamburger.on('click', function() {
							if (!menuActive) {
									openMenu();
							}
					});
			}

			if (fsOverlay.length) {
					fsOverlay.on('click', closeMenu);
			}

			if (hamburgerClose.length) {
					hamburgerClose.on('click', closeMenu);
			}

			if ($('.menu_item').length) {
					$('.menu_item.has-children').on('click', function() {
							$(this).toggleClass('active');
							var panel = $(this).children('.menu_selection');
							panel.css('maxHeight', panel.css('maxHeight') ? null : panel.prop('scrollHeight') + "px");
					});
			}
	}

	/* Open the hamburger menu */
	function openMenu() {
			menu.addClass('active');
			fsOverlay.css('pointer-events', "auto");
			menuActive = true;
	}

	/* Close the hamburger menu */
	function closeMenu() {
			menu.removeClass('active');
			fsOverlay.css('pointer-events', "none");
			menuActive = false;
	}

	/* Initialize Google Maps */
	function initGoogleMap() {
			var myLatlng = new google.maps.LatLng(42.373122, -71.112387);
			var mapOptions = {
					center: myLatlng,
					zoom: 16,
					mapTypeId: google.maps.MapTypeId.ROADMAP,
					draggable: true,
					scrollwheel: false,
					zoomControl: true,
					zoomControlOptions: { position: google.maps.ControlPosition.RIGHT_CENTER },
					mapTypeControl: false,
					scaleControl: false,
					streetViewControl: false,
					rotateControl: false,
					fullscreenControl: true,
					styles: [
							{ "elementType": "geometry", "stylers": [{ "color": "#f5f5f5" }] },
							{ "elementType": "labels.icon", "stylers": [{ "visibility": "off" }] },
							{ "elementType": "labels.text.fill", "stylers": [{ "color": "#616161" }] },
							{ "elementType": "labels.text.stroke", "stylers": [{ "color": "#f5f5f5" }] },
							{ "featureType": "poi", "elementType": "geometry", "stylers": [{ "color": "#eeeeee" }] },
							{ "featureType": "poi.park", "elementType": "geometry", "stylers": [{ "color": "#e5e5e5" }] },
							{ "featureType": "road", "elementType": "geometry", "stylers": [{ "color": "#ffffff" }] },
							{ "featureType": "water", "elementType": "geometry", "stylers": [{ "color": "#c9c9c9" }] }
					]
			};

			// Initialize the map
			map = new google.maps.Map(document.getElementById('map'), mapOptions);

			// Use a custom marker
			var image = 'images/map_marker.png'; // Update the path to your marker image
			var marker = new google.maps.Marker({
					position: new google.maps.LatLng(42.373122, -71.112387),
					map: map,
					icon: image
			});

			// Re-center the map after window resize
			google.maps.event.addDomListener(window, 'resize', function() {
					setTimeout(function() {
							google.maps.event.trigger(map, "resize");
							map.setCenter(myLatlng);
					}, 1400);
			});
	}
});
