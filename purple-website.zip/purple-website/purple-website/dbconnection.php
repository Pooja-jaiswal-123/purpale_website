<?php

// Define database credentials as constants
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', ''); // Typically empty in XAMPP
define('DB_NAME', 'login_register');

// Create the database connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

// Check if the connection is successful
if (!$conn) {
    // Log the error message (useful for debugging)
    error_log("Database connection error: " . mysqli_connect_error());
    die("Database connection failed. Please try again later.");
} else {
    // Debugging message (only for development)
    // Comment or remove this in production
    echo "Connection successful!";
}
