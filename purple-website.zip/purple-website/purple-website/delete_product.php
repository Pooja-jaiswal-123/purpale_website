<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'login_register');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if product_id is provided and is a valid integer
if (isset($_POST['product_id']) && is_numeric($_POST['product_id'])) {
    // Sanitize the product ID to ensure it's an integer
    $product_id = intval($_POST['product_id']);

    // Prepare statement to prevent SQL injection
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);

    // Execute query
    if ($stmt->execute()) {
        // Redirect with success message
        header("Location: admin_dashboard.php?msg=Product deleted successfully");
    } else {
        // Redirect with error message
        header("Location: admin_dashboard.php?msg=Error deleting product");
    }

    $stmt->close();
} else {
    // Redirect with validation error message
    header("Location: admin_dashboard.php?msg=Invalid or missing product ID");
}

// Close the database connection
$conn->close();
exit;
